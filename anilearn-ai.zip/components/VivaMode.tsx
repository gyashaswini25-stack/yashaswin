import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Play, RefreshCcw, Award, ChevronRight, Zap, Keyboard, Send } from 'lucide-react';
import { evaluateVivaAnswer } from '../services/geminiService';
import { VivaFeedback, VivaState } from '../types';

interface Props {
  onBack: () => void;
  topic?: string;
}

const VivaMode: React.FC<Props> = ({ onBack, topic }) => {
  const [state, setState] = useState<VivaState>(VivaState.IDLE);
  const [question, setQuestion] = useState(topic ? `Tell me everything you know about ${topic}.` : "What topic would you like to practice today?");
  const [transcript, setTranscript] = useState('');
  const [feedback, setFeedback] = useState<VivaFeedback | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [useTextInput, setUseTextInput] = useState(false);
  const [textInput, setTextInput] = useState('');
  
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      
      recognitionRef.current.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        setTranscript(prev => finalTranscript ? prev + ' ' + finalTranscript : prev + interimTranscript);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error("Speech error", event.error);
        if (event.error === 'network') {
            setError("Network error with Speech API. Switching to text mode is recommended.");
        } else if (event.error === 'not-allowed') {
            setError("Microphone permission denied.");
        } else {
            setError(`Speech recognition error: ${event.error}`);
        }
        setState(VivaState.IDLE);
      };
      
      recognitionRef.current.onend = () => {
          if (state === VivaState.LISTENING) {
              // Automatically restart if we think we are still listening? 
              // Better to just let user manually restart to avoid loops.
              // setState(VivaState.IDLE); 
          }
      };
    } else {
       setError("Speech recognition not supported in this browser.");
       setUseTextInput(true);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const startListening = () => {
    setError(null);
    setTranscript('');
    setFeedback(null);
    setState(VivaState.LISTENING);
    try {
        recognitionRef.current?.start();
    } catch (e) {
        console.error(e);
        setState(VivaState.IDLE);
    }
  };

  const stopListening = async () => {
    recognitionRef.current?.stop();
    processAnswer(transcript);
  };
  
  const handleTextSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (textInput.trim()) {
          setTranscript(textInput);
          processAnswer(textInput);
      }
  };

  const processAnswer = async (answerText: string) => {
    setState(VivaState.PROCESSING);
    
    // If it's the initial setup phase
    if (!topic && !question.includes('Tell me')) {
       setQuestion(`Tell me about ${answerText}. Start answering whenever you are ready.`);
       setTranscript('');
       setTextInput('');
       setState(VivaState.IDLE);
       return;
    }

    try {
      const result = await evaluateVivaAnswer(question, answerText);
      setFeedback(result);
      setState(VivaState.FEEDBACK);
    } catch (e) {
      console.error(e);
      setError("AI evaluation failed. Please try again.");
      setState(VivaState.IDLE);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 md:p-10 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
            <button onClick={onBack} className="text-slate-400 hover:text-white transition px-4 py-2 rounded-full border border-slate-800 hover:bg-slate-800">
            Exit Mode
            </button>
            <div className="h-6 w-[1px] bg-slate-700"></div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">AI Viva Examiner</h2>
        </div>
        <button 
           onClick={() => setUseTextInput(!useTextInput)}
           className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
        >
            <Keyboard size={16} /> {useTextInput ? "Switch to Voice" : "Switch to Text"}
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-10 relative">
        
        {/* Dynamic Background */}
        {state === VivaState.LISTENING && !useTextInput && (
           <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] animate-pulse"></div>
           </div>
        )}

        {/* Central Visualization */}
        <div className="relative z-10 w-full">
           {!useTextInput && (
            <div className={`relative w-48 h-48 mx-auto flex items-center justify-center transition-all duration-500 ${state === VivaState.LISTENING ? 'scale-110' : 'scale-100'}`}>
              {/* Pulsating Rings */}
              {state === VivaState.LISTENING && (
                <>
                  <div className="absolute inset-0 rounded-full border border-indigo-500/30 animate-[ping_1.5s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
                  <div className="absolute inset-[-20px] rounded-full border border-indigo-500/20 animate-[ping_2s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
                </>
              )}

              {/* Main Circle */}
              <div className={`w-40 h-40 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(79,70,229,0.2)] border-4 transition-all duration-300
                  ${state === VivaState.LISTENING ? 'bg-indigo-600 border-indigo-400' : 'bg-slate-800 border-slate-700'}
                  ${state === VivaState.PROCESSING ? 'animate-pulse bg-indigo-900 border-indigo-700' : ''}
              `}>
                  {state === VivaState.LISTENING ? (
                    <div className="flex gap-1.5 items-end h-16 pb-2">
                       {[1,2,3,4,5].map(i => (
                          <div key={i} className="w-2.5 bg-white rounded-full animate-[bounce_1s_infinite]" style={{animationDelay: `${i*0.1}s`, height: `${30 + Math.random()*70}%`}}></div>
                       ))}
                    </div>
                  ) : state === VivaState.PROCESSING ? (
                    <RefreshCcw size={40} className="text-indigo-400 animate-spin" />
                  ) : (
                    <Mic size={48} className="text-indigo-400" />
                  )}
              </div>
            </div>
           )}
           
           <div className="mt-8 text-center space-y-2">
              <p className="text-sm font-bold text-indigo-400 uppercase tracking-widest">
                  {state === VivaState.LISTENING ? 'Listening...' : state === VivaState.PROCESSING ? 'Analyzing...' : 'Ready'}
              </p>
              <h3 className="text-3xl font-medium text-white leading-relaxed max-w-3xl mx-auto">"{question}"</h3>
              
              {error && (
                  <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-300 text-sm inline-block">
                      {error}
                  </div>
              )}
           </div>
        </div>

        {/* Input Area (Text or Voice Transcript) */}
        <div className="w-full max-w-2xl relative z-20">
            {useTextInput ? (
                state !== VivaState.FEEDBACK && state !== VivaState.PROCESSING && (
                    <form onSubmit={handleTextSubmit} className="relative">
                        <input
                           type="text"
                           value={textInput}
                           onChange={(e) => setTextInput(e.target.value)}
                           className="w-full bg-slate-800/80 border border-slate-600 rounded-2xl py-4 pl-6 pr-14 text-lg text-white placeholder:text-slate-500 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none shadow-xl"
                           placeholder="Type your answer here..."
                           autoFocus
                        />
                        <button 
                          type="submit" 
                          disabled={!textInput.trim()}
                          className="absolute right-2 top-2 p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                            <Send size={20} />
                        </button>
                    </form>
                )
            ) : (
                state !== VivaState.FEEDBACK && transcript && (
                    <div className="p-6 bg-slate-900/50 backdrop-blur rounded-2xl border border-slate-800/50 text-center animate-in fade-in slide-in-from-bottom-4">
                        <p className="text-slate-300 text-lg">"{transcript}"</p>
                    </div>
                )
            )}
        </div>

        {/* Feedback Card */}
        {state === VivaState.FEEDBACK && feedback && (
           <div className="w-full max-w-3xl animate-in slide-in-from-bottom-8 duration-500">
              <div className="glass-panel p-8 rounded-3xl border-t border-white/10 shadow-2xl">
                 <div className="flex flex-col md:flex-row items-center justify-between mb-8 gap-6 border-b border-white/5 pb-6">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-yellow-500/20 rounded-xl text-yellow-400">
                            <Award size={32} />
                        </div>
                        <div>
                            <h4 className="text-xl font-bold text-white">Performance Report</h4>
                            <p className="text-slate-400 text-sm">AI Analysis of your answer</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 bg-slate-800/50 px-5 py-3 rounded-2xl border border-slate-700">
                       <span className="text-slate-400 font-medium">Confidence Score</span>
                       <span className={`text-3xl font-bold ${feedback.score > 75 ? 'text-emerald-400' : feedback.score > 50 ? 'text-amber-400' : 'text-red-400'}`}>{feedback.score}%</span>
                    </div>
                 </div>
                 
                 <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                        <div className="p-5 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                            <h5 className="text-indigo-300 font-semibold mb-2 flex items-center gap-2"><Zap size={16} /> AI Feedback</h5>
                            <p className="text-indigo-100/80 leading-relaxed">{feedback.feedback}</p>
                        </div>
                        <div>
                            <h5 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-3">Improvement Tips</h5>
                            <ul className="space-y-3">
                                {feedback.tips.map((tip, idx) => (
                                <li key={idx} className="flex items-start gap-3 text-slate-300">
                                    <div className="mt-1 w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-indigo-400 border border-slate-700 text-xs">
                                        {idx + 1}
                                    </div> 
                                    <span>{tip}</span>
                                </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                    
                    <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
                       <h5 className="text-sm font-bold text-emerald-400 uppercase tracking-wider mb-3">Model Answer</h5>
                       <p className="text-slate-300 leading-relaxed italic">"{feedback.correctedAnswer}"</p>
                    </div>
                 </div>
              </div>
           </div>
        )}

        {/* Action Buttons (Only for Voice Mode) */}
        {!useTextInput && (
            <div className="z-20">
            {state === VivaState.LISTENING ? (
                <button
                onClick={stopListening}
                className="flex items-center gap-3 bg-red-500 hover:bg-red-400 text-white px-8 py-4 rounded-full font-bold shadow-lg shadow-red-500/30 transition-all hover:scale-105 active:scale-95"
                >
                <Square size={20} fill="currentColor" />
                Stop & Check Answer
                </button>
            ) : (
                <button
                onClick={startListening}
                disabled={state === VivaState.PROCESSING}
                className="flex items-center gap-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white px-10 py-5 rounded-full font-bold text-lg shadow-xl shadow-indigo-600/30 transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:scale-100"
                >
                {state === VivaState.PROCESSING ? (
                    <>Processing...</>
                ) : (
                    <><Mic size={24} /> {state === VivaState.FEEDBACK ? "Answer Again" : "Start Answer"}</>
                )}
                </button>
            )}
            </div>
        )}
        
        {useTextInput && state === VivaState.FEEDBACK && (
             <button
                onClick={() => {
                    setTextInput('');
                    setTranscript('');
                    setFeedback(null);
                    setState(VivaState.IDLE);
                }}
                className="flex items-center gap-3 bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-xl font-bold transition-all"
             >
                 Answer Again
             </button>
        )}

      </div>
    </div>
  );
};

export default VivaMode;