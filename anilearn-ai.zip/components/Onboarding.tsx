import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Sparkles, BookOpen, GraduationCap, ArrowRight, Check } from 'lucide-react';

interface Props {
  onComplete: (profile: UserProfile) => void;
}

const Onboarding: React.FC<Props> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  const [examGoal, setExamGoal] = useState('');
  const [style, setStyle] = useState<'visual' | 'text' | 'audio'>('visual');

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      onComplete({
        name,
        grade,
        examGoal,
        style,
        points: 0,
        streak: 0,
        badges: []
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if ((step === 1 && name) || (step === 2 && grade)) {
        handleNext();
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden">
      {/* Dynamic Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/20 rounded-full blur-[120px] animate-pulse" style={{animationDelay: '2s'}}></div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Logo Header */}
        <div className="text-center mb-10 animate-float">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-500/20 to-purple-500/20 border border-white/10 mb-6 backdrop-blur-xl shadow-2xl">
            <Sparkles className="w-10 h-10 text-indigo-400" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-3 tracking-tight">
            Ani<span className="gradient-text">Learn</span>
          </h1>
          <p className="text-slate-400 text-lg font-light">Your intelligent study companion.</p>
        </div>

        {/* Card Container */}
        <div className="glass-panel p-8 md:p-10 rounded-3xl shadow-2xl border border-white/10 relative overflow-hidden">
           {/* Progress Bar */}
           <div className="absolute top-0 left-0 h-1 bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-500" style={{ width: `${(step / 3) * 100}%` }}></div>

           {/* Step 1: Name */}
           {step === 1 && (
             <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
               <div className="space-y-2">
                 <h2 className="text-2xl font-semibold text-white">Let's start with your name</h2>
                 <p className="text-slate-400 text-sm">We'll personalize your learning experience.</p>
               </div>
               
               <input
                 type="text"
                 value={name}
                 onChange={(e) => setName(e.target.value)}
                 onKeyDown={handleKeyDown}
                 className="w-full bg-slate-900/50 border border-slate-700 focus:border-indigo-500 rounded-xl p-4 text-white text-lg placeholder:text-slate-600 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all shadow-inner"
                 placeholder="Type your name here..."
                 autoFocus
               />
               
               <button
                 onClick={handleNext}
                 disabled={!name}
                 className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold py-4 rounded-xl transition-all shadow-lg shadow-indigo-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 group"
               >
                 Continue <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
               </button>
             </div>
           )}

           {/* Step 2: Academic Info */}
           {step === 2 && (
             <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
               <div className="space-y-2">
                 <h2 className="text-2xl font-semibold text-white">What are you studying?</h2>
                 <p className="text-slate-400 text-sm">Tailoring content to your level.</p>
               </div>

               <div className="space-y-4">
                 <div className="relative">
                   <select
                     value={grade}
                     onChange={(e) => setGrade(e.target.value)}
                     className="w-full bg-slate-900/50 border border-slate-700 focus:border-indigo-500 rounded-xl p-4 text-white text-lg appearance-none outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all cursor-pointer"
                   >
                     <option value="" className="text-slate-500">Select Class / Grade</option>
                     <option value="Class 10">Class 10 (High School)</option>
                     <option value="Class 11">Class 11 (Intermediate)</option>
                     <option value="Class 12">Class 12 (Senior Secondary)</option>
                     <option value="College">College / University</option>
                     <option value="Professional">Professional Learning</option>
                   </select>
                   <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                     <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                   </div>
                 </div>

                 <input
                   type="text"
                   value={examGoal}
                   onChange={(e) => setExamGoal(e.target.value)}
                   onKeyDown={handleKeyDown}
                   className="w-full bg-slate-900/50 border border-slate-700 focus:border-indigo-500 rounded-xl p-4 text-white text-lg placeholder:text-slate-600 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
                   placeholder="Target Exam (e.g. NEET, JEE) - Optional"
                 />
               </div>

               <div className="flex gap-3">
                 <button
                   onClick={() => setStep(step - 1)}
                   className="px-6 py-4 rounded-xl font-medium text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
                 >
                   Back
                 </button>
                 <button
                   onClick={handleNext}
                   disabled={!grade}
                   className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold py-4 rounded-xl transition-all shadow-lg shadow-indigo-500/25 disabled:opacity-50 flex items-center justify-center gap-2 group"
                 >
                   Next <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                 </button>
               </div>
             </div>
           )}

           {/* Step 3: Learning Style */}
           {step === 3 && (
             <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-500">
               <div className="space-y-2">
                 <h2 className="text-2xl font-semibold text-white">Choose your learning style</h2>
                 <p className="text-slate-400 text-sm">How do you understand best?</p>
               </div>

               <div className="grid grid-cols-1 gap-3">
                 {[
                   { id: 'visual', icon: Sparkles, title: 'Visual Learner', desc: 'I learn best with animations, images, and diagrams.', color: 'indigo' },
                   { id: 'text', icon: BookOpen, title: 'Text Learner', desc: 'I prefer detailed notes and structured reading.', color: 'emerald' },
                   { id: 'audio', icon: GraduationCap, title: 'Interactive Learner', desc: 'I like voice discussions and viva practice.', color: 'pink' }
                 ].map((option) => (
                   <button
                     key={option.id}
                     onClick={() => setStyle(option.id as any)}
                     className={`relative p-4 rounded-2xl border transition-all duration-300 text-left group
                       ${style === option.id 
                         ? `bg-${option.color}-500/10 border-${option.color}-500 ring-1 ring-${option.color}-500 shadow-[0_0_20px_rgba(0,0,0,0.2)]` 
                         : 'bg-slate-800/40 border-slate-700 hover:bg-slate-800 hover:border-slate-600'
                       }`}
                   >
                     <div className="flex items-start gap-4">
                       <div className={`p-3 rounded-xl transition-colors ${style === option.id ? `bg-${option.color}-500 text-white shadow-lg` : `bg-slate-800 text-slate-400 group-hover:text-white`}`}>
                         <option.icon size={24} />
                       </div>
                       <div className="flex-1">
                         <h3 className={`font-bold text-lg mb-1 ${style === option.id ? 'text-white' : 'text-slate-200'}`}>{option.title}</h3>
                         <p className="text-sm text-slate-400 leading-relaxed">{option.desc}</p>
                       </div>
                       {style === option.id && (
                         <div className={`absolute top-4 right-4 w-6 h-6 rounded-full bg-${option.color}-500 flex items-center justify-center`}>
                           <Check size={14} className="text-white" strokeWidth={3} />
                         </div>
                       )}
                     </div>
                   </button>
                 ))}
               </div>
               
               <div className="flex gap-3 pt-2">
                 <button
                   onClick={() => setStep(step - 1)}
                   className="px-6 py-4 rounded-xl font-medium text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
                 >
                   Back
                 </button>
                 <button
                   onClick={handleNext}
                   className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-500/30 transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
                 >
                   Launch App <Sparkles size={18} />
                 </button>
               </div>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default Onboarding;