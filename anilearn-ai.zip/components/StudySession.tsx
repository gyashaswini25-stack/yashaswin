import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Image as ImageIcon, FileText, GitMerge, BrainCircuit, CheckCircle, Volume2, ArrowLeft, ChevronRight, Maximize2, Sparkles, Loader2, RefreshCw } from 'lucide-react';
import { generateStudyContent, generateVisual, generateSpeech, generateVideoLoop } from '../services/geminiService';
import { UserProfile, StudyResponse } from '../types';

interface Props {
  topic: string;
  user: UserProfile;
  onBack: () => void;
  onPointsUpdate: (pts: number) => void;
}

const StudySession: React.FC<Props> = ({ topic, user, onBack, onPointsUpdate }) => {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<StudyResponse | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'visual' | 'text' | 'flow' | 'quiz'>('visual');
  const [quizSelected, setQuizSelected] = useState<number | null>(null);
  const [quizResult, setQuizResult] = useState<'correct' | 'wrong' | null>(null);
  
  // Audio Player State
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const startTimeRef = useRef<number>(0);
  const pauseTimeRef = useRef<number>(0);
  const animationFrameRef = useRef<number>(0);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const data = await generateStudyContent(topic, user.style, user.grade);
        setContent(data);
        
        // 1. Start Image Gen (Fast)
        generateVisual(data.visualPrompt).then(setImageUrl);

        // 2. Start Video Gen (Slow, Background)
        setIsVideoLoading(true);
        generateVideoLoop(data.visualPrompt).then(url => {
            if (url) setVideoUrl(url);
            setIsVideoLoading(false);
        });
        
        // 3. Start Audio Gen
        const buffer = await generateSpeech(data.explanation);
        
        // Decode Audio
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        audioContextRef.current = ctx;

        const dataInt16 = new Int16Array(buffer);
        const float32Data = new Float32Array(dataInt16.length);
        for (let i = 0; i < dataInt16.length; i++) {
           float32Data[i] = dataInt16[i] / 32768.0;
        }

        const audioBuf = ctx.createBuffer(1, float32Data.length, 24000);
        audioBuf.copyToChannel(float32Data, 0);
        setAudioBuffer(audioBuf);
        setDuration(audioBuf.duration);

      } catch (error) {
        console.error("Failed to load study content", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();

    return () => {
      stopAudio();
      if (audioContextRef.current) audioContextRef.current.close();
      cancelAnimationFrame(animationFrameRef.current);
    };
  }, [topic, user]);

  const updateProgress = () => {
    if (audioContextRef.current && isPlaying) {
      const elapsed = audioContextRef.current.currentTime - startTimeRef.current;
      setCurrentTime(Math.min(elapsed, duration));
      
      if (elapsed < duration) {
        animationFrameRef.current = requestAnimationFrame(updateProgress);
      } else {
        setIsPlaying(false);
        pauseTimeRef.current = 0;
        setCurrentTime(0);
      }
    }
  };

  const playAudio = () => {
    if (!audioContextRef.current || !audioBuffer) return;

    // Clean up previous source
    if (sourceNodeRef.current) {
        sourceNodeRef.current.disconnect();
    }

    const source = audioContextRef.current.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContextRef.current.destination);
    
    // Handle pause offset
    const offset = pauseTimeRef.current % audioBuffer.duration;
    source.start(0, offset);
    
    startTimeRef.current = audioContextRef.current.currentTime - offset;
    sourceNodeRef.current = source;
    
    setIsPlaying(true);
    updateProgress();
  };

  const pauseAudio = () => {
    if (sourceNodeRef.current && audioContextRef.current) {
      sourceNodeRef.current.stop();
      cancelAnimationFrame(animationFrameRef.current);
      pauseTimeRef.current = audioContextRef.current.currentTime - startTimeRef.current;
      setIsPlaying(false);
    }
  };

  const stopAudio = () => {
    if (sourceNodeRef.current) {
        sourceNodeRef.current.stop();
        sourceNodeRef.current.disconnect();
    }
    cancelAnimationFrame(animationFrameRef.current);
    setIsPlaying(false);
  };

  const toggleAudio = () => {
      if (isPlaying) {
          pauseAudio();
      } else {
          if (audioContextRef.current?.state === 'suspended') {
              audioContextRef.current.resume();
          }
          playAudio();
      }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newTime = parseFloat(e.target.value);
      setCurrentTime(newTime);
      pauseTimeRef.current = newTime;
      if (isPlaying) {
          playAudio(); // Restart from new time
      }
  };

  const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleQuizSubmit = (index: number) => {
    if (quizResult !== null) return; 
    setQuizSelected(index);
    const isCorrect = index === content?.quizAnswer;
    setQuizResult(isCorrect ? 'correct' : 'wrong');
    if (isCorrect) onPointsUpdate(50);
  };
  
  const handleKeySelection = async () => {
      if ((window as any).aistudio) {
          try {
              await (window as any).aistudio.openSelectKey();
              // Retrigger video gen
              if (content) {
                setIsVideoLoading(true);
                generateVideoLoop(content.visualPrompt).then(url => {
                    if (url) setVideoUrl(url);
                    setIsVideoLoading(false);
                });
              }
          } catch (e) {
              console.error(e);
          }
      }
  };

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center space-y-8 animate-in fade-in duration-500">
        <div className="relative">
             <div className="w-24 h-24 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin"></div>
             <div className="absolute inset-0 flex items-center justify-center">
                 <BrainCircuit className="w-8 h-8 text-indigo-400 animate-pulse" />
             </div>
        </div>
        <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-2 tracking-tight">Crafting Your Lesson</h2>
            <p className="text-slate-400">Our AI teacher is writing the script and rendering visuals...</p>
        </div>
      </div>
    );
  }

  if (!content) return <div className="p-10 text-center text-red-400">Unable to load content. Please try again later.</div>;

  return (
    <div className="h-full flex flex-col p-6 md:p-8 max-w-7xl mx-auto gap-6">
      
      {/* Top Navigation Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
           <button 
             onClick={onBack} 
             className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 hover:border-slate-600"
           >
             <ArrowLeft size={20} />
           </button>
           <div>
              <p className="text-xs text-indigo-400 font-bold uppercase tracking-wider mb-1">Studying</p>
              <h1 className="text-3xl font-bold text-white leading-none">{topic}</h1>
           </div>
        </div>

        {/* Floating Tab Switcher */}
        <div className="bg-slate-900/80 backdrop-blur-md p-1.5 rounded-2xl border border-slate-800 flex gap-1 shadow-xl">
           {[
             { id: 'visual', icon: ImageIcon, label: 'Video Lesson' },
             { id: 'text', icon: FileText, label: 'Read' },
             { id: 'flow', icon: GitMerge, label: 'Steps' },
             { id: 'quiz', icon: CheckCircle, label: 'Quiz' }
           ].map((tab) => (
             <button 
               key={tab.id}
               onClick={() => setActiveTab(tab.id as any)}
               className={`px-4 py-2.5 rounded-xl flex items-center gap-2 text-sm font-semibold transition-all duration-300 ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
             >
               <tab.icon size={16} /> <span className="hidden sm:inline">{tab.label}</span>
             </button>
           ))}
        </div>
      </div>

      <div className="flex-1 flex gap-8 min-h-0">
         {/* Main Content Panel */}
         <div className="flex-1 glass-panel rounded-3xl p-6 md:p-8 overflow-y-auto shadow-2xl relative scroll-smooth">
            
            {activeTab === 'visual' && (
              <div className="h-full flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-500">
                 
                 {/* Simulated Video Player */}
                 <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl group select-none">
                     {videoUrl ? (
                         <video 
                            src={videoUrl} 
                            autoPlay 
                            loop 
                            muted 
                            className={`w-full h-full object-cover transition-opacity duration-1000`} 
                         />
                     ) : imageUrl ? (
                         <>
                           <img src={imageUrl} alt="Visual Explanation" className={`w-full h-full object-cover transition-transform duration-[20s] ease-linear ${isPlaying ? 'scale-125' : 'scale-100'}`} />
                           <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                           
                           {/* Status Badge */}
                           {isVideoLoading && (
                               <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-white/10 text-xs text-indigo-300 shadow-lg">
                                   <Loader2 size={12} className="animate-spin" /> Rendering HD Video...
                               </div>
                           )}
                           
                           {/* Key Prompt Button */}
                           {!isVideoLoading && !videoUrl && (window as any).aistudio && (
                               <div className="absolute top-4 right-4">
                                   <button onClick={handleKeySelection} className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600/80 hover:bg-indigo-600 backdrop-blur-md rounded-full text-xs text-white font-bold transition-all">
                                      <Sparkles size={12} /> Enable HD Video
                                   </button>
                               </div>
                           )}
                         </>
                     ) : (
                         <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900">
                              <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mb-4"></div>
                              <span className="text-slate-400 font-medium">Generating Visuals...</span>
                         </div>
                     )}
                     
                     {/* Big Play Button Overlay (when paused) */}
                     {!isPlaying && audioBuffer && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[2px] transition-opacity z-10">
                            <button 
                                onClick={toggleAudio}
                                className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white p-6 rounded-full shadow-[0_0_40px_rgba(255,255,255,0.1)] transform hover:scale-110 transition-all group/playbtn"
                            >
                                <Play size={48} fill="currentColor" className="ml-2 text-indigo-400 group-hover/playbtn:text-white transition-colors" />
                            </button>
                        </div>
                     )}

                     {/* Video Controls Bar */}
                     <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent flex flex-col gap-2 opacity-100 transition-opacity z-20">
                        {/* Progress Slider */}
                        <div className="relative group/slider h-4 flex items-center cursor-pointer">
                            <input 
                                type="range" 
                                min="0" 
                                max={duration || 100} 
                                value={currentTime} 
                                onChange={handleSeek}
                                className="absolute w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-indigo-500 [&::-webkit-slider-thumb]:shadow-[0_0_10px_rgba(99,102,241,0.5)]"
                            />
                            <div className="h-1 bg-indigo-500 rounded-full pointer-events-none" style={{ width: `${(currentTime / duration) * 100}%` }}></div>
                        </div>

                        {/* Controls Row */}
                        <div className="flex items-center justify-between text-white">
                            <div className="flex items-center gap-4">
                                <button onClick={toggleAudio} className="hover:text-indigo-400 transition hover:scale-110 active:scale-95">
                                    {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" />}
                                </button>
                                <div className="text-sm font-medium font-mono text-slate-300">
                                    {formatTime(currentTime)} / {formatTime(duration)}
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <Maximize2 size={20} className="text-slate-400 hover:text-white cursor-pointer" />
                            </div>
                        </div>
                     </div>
                 </div>
                 
                 {/* Captions / Transcript Area */}
                 <div className="flex-1 min-h-0 flex flex-col">
                     <div className="p-6 bg-slate-900/40 rounded-2xl border border-white/5 backdrop-blur-sm">
                        <h3 className="text-indigo-400 font-bold mb-4 flex items-center gap-2 text-xs uppercase tracking-widest">
                            <Volume2 size={14}/> Video Script
                        </h3>
                        <div className="prose prose-invert max-w-none">
                            <p className="text-slate-200 text-lg leading-loose font-light">
                                {content.explanation}
                            </p>
                        </div>
                     </div>
                 </div>
              </div>
            )}

            {activeTab === 'text' && (
              <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
                 <div className="prose prose-invert prose-lg max-w-none">
                    <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 mb-6">In-Depth Breakdown</h2>
                    <div className="text-slate-200 leading-8 whitespace-pre-line text-lg font-light">
                        {content.explanation}
                    </div>
                 </div>
                 
                 <div className="mt-10 p-8 bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-3xl relative overflow-hidden group hover:border-amber-500/40 transition-colors">
                     <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:scale-110 transition-transform duration-700">
                        <BrainCircuit size={120} />
                     </div>
                     <h4 className="text-amber-400 font-bold flex items-center gap-2 mb-4 text-lg relative z-10 uppercase tracking-wider">
                         <BrainCircuit size={20} /> Memory Cheat Code
                     </h4>
                     <p className="text-amber-100 text-2xl font-serif italic relative z-10 leading-relaxed">
                         "{content.memoryTrick}"
                     </p>
                 </div>
              </div>
            )}

            {activeTab === 'flow' && (
              <div className="h-full flex flex-col items-center justify-center py-8 animate-in fade-in zoom-in-95 duration-500">
                  <h3 className="text-2xl font-bold text-white mb-10">Step-by-Step Logic</h3>
                  <div className="relative flex flex-col gap-0 w-full max-w-xl">
                     {content.flowchartSteps.map((step, idx) => (
                         <div key={idx} className="relative flex flex-col items-center group">
                              {/* Connector Line */}
                              {idx > 0 && <div className="h-10 w-0.5 bg-slate-700 my-1 group-hover:bg-indigo-500/50 transition-colors"></div>}
                              
                              <div 
                                className="w-full bg-slate-800/80 backdrop-blur border border-slate-700 p-6 rounded-2xl shadow-lg hover:border-indigo-500 hover:bg-slate-800 hover:shadow-indigo-500/20 transition-all transform hover:-translate-y-1"
                                style={{animation: `fadeInUp 0.5s ease-out forwards ${idx * 0.15}s`, opacity: 0}}
                              >
                                 <div className="flex items-center gap-5">
                                     <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center text-lg font-bold text-slate-300 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-inner">
                                         {idx + 1}
                                     </div>
                                     <span className="text-lg text-slate-200 font-medium leading-snug">{step}</span>
                                 </div>
                              </div>
                         </div>
                     ))}
                  </div>
              </div>
            )}

            {activeTab === 'quiz' && (
              <div className="h-full flex flex-col items-center justify-center p-4 animate-in fade-in slide-in-from-right-4 duration-500">
                 <div className="w-full max-w-2xl">
                     <div className="mb-10 text-center">
                        <span className="inline-block px-4 py-1.5 bg-indigo-500/10 text-indigo-400 rounded-full text-xs font-bold uppercase tracking-widest mb-6 border border-indigo-500/20">Knowledge Check</span>
                        <h3 className="text-3xl font-bold text-white leading-snug">{content.quizQuestion}</h3>
                     </div>
                     
                     <div className="grid grid-cols-1 gap-4">
                         {content.quizOptions.map((option, idx) => (
                             <button
                               key={idx}
                               onClick={() => handleQuizSubmit(idx)}
                               disabled={quizResult !== null}
                               className={`group relative w-full p-6 rounded-2xl text-left font-medium text-lg transition-all transform hover:scale-[1.02] border-2 shadow-lg
                                 ${quizSelected === idx 
                                     ? (idx === content.quizAnswer 
                                         ? 'bg-emerald-900/20 border-emerald-500 text-emerald-100 shadow-emerald-900/20' 
                                         : 'bg-red-900/20 border-red-500 text-red-100 shadow-red-900/20')
                                     : (quizResult !== null && idx === content.quizAnswer 
                                         ? 'bg-emerald-900/20 border-emerald-500 text-emerald-100' 
                                         : 'bg-slate-800/40 border-slate-700 hover:bg-slate-800 hover:border-indigo-500/50 text-slate-300')
                                 }
                               `}
                             >
                               <div className="flex items-center justify-between relative z-10">
                                  <span>{option}</span>
                                  {quizResult !== null && idx === content.quizAnswer && <CheckCircle className="text-emerald-500" size={24} />}
                                  {quizResult !== null && idx === quizSelected && idx !== content.quizAnswer && <span className="text-red-400 font-bold">Wrong</span>}
                               </div>
                             </button>
                         ))}
                     </div>

                     {quizResult === 'correct' && (
                         <div className="mt-8 p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-center animate-bounce-in">
                             <div className="text-5xl mb-4">🎉</div>
                             <h4 className="text-xl font-bold text-emerald-400">Perfect Score! +50 XP</h4>
                             <p className="text-emerald-200/70 text-sm mt-1">You've mastered this concept completely.</p>
                         </div>
                     )}
                     {quizResult === 'wrong' && (
                         <div className="mt-8 p-6 bg-red-500/10 border border-red-500/20 rounded-2xl text-center">
                             <h4 className="text-xl font-bold text-red-400">Needs Review</h4>
                             <p className="text-red-200/70 mt-1">Check the "Read" tab again to find the answer.</p>
                         </div>
                     )}
                 </div>
              </div>
            )}
         </div>

         {/* Sidebar Stats (Desktop Only) */}
         <div className="hidden lg:flex w-80 flex-col gap-6">
             <div className="glass-panel p-6 rounded-3xl">
                 <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-6">Session Stats</h4>
                 <div className="space-y-6">
                     <div>
                         <div className="flex justify-between text-sm mb-2">
                             <span className="text-slate-400">Understanding</span>
                             <span className="text-white font-bold">85%</span>
                         </div>
                         <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                             <div className="bg-gradient-to-r from-indigo-500 to-purple-500 w-[85%] h-full rounded-full"></div>
                         </div>
                     </div>
                     <div>
                         <div className="flex justify-between text-sm mb-2">
                             <span className="text-slate-400">Time Spent</span>
                             <span className="text-white font-bold">4m 20s</span>
                         </div>
                         <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                             <div className="bg-slate-600 w-[30%] h-full rounded-full"></div>
                         </div>
                     </div>
                 </div>
             </div>

             <div className="glass-panel p-6 rounded-3xl flex-1 flex flex-col">
                 <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Related Topics</h4>
                 <div className="flex-1 space-y-2">
                     {['Advanced Applications', 'Case Studies', 'Historical Timeline', 'Formula Sheet'].map((item, i) => (
                         <button key={i} className="w-full text-left p-3 rounded-xl hover:bg-white/5 text-slate-400 hover:text-indigo-300 transition-colors text-sm flex items-center justify-between group">
                             {item}
                             <ChevronRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                         </button>
                     ))}
                 </div>
             </div>
         </div>
      </div>
    </div>
  );
};

export default StudySession;