import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Search, Mic, Upload, Book, Award, Zap, Sparkles, TrendingUp, ChevronRight, Video, GraduationCap } from 'lucide-react';

interface Props {
  user: UserProfile;
  onTopicSelect: (topic: string) => void;
  onVivaSelect: () => void;
}

const Dashboard: React.FC<Props> = ({ user, onTopicSelect, onVivaSelect }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) onTopicSelect(input);
  };

  return (
    <div className="min-h-full p-6 md:p-10 max-w-6xl mx-auto flex flex-col gap-12">
      
      {/* Hero Section */}
      <div className="relative pt-6">
         {/* Decorative Blur */}
         <div className="absolute -top-32 -left-20 w-96 h-96 bg-indigo-500/20 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
         <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-[80px] pointer-events-none"></div>
         
         <div className="flex flex-col md:flex-row justify-between items-end gap-6 relative z-10">
            <div>
               <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-medium mb-4 text-xs uppercase tracking-wider">
                  <Sparkles size={12} /> AI Learning Companion Active
               </div>
               <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-3 leading-tight tracking-tight">
                  Hello, <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">{user.name}</span>
               </h1>
               <p className="text-slate-400 text-lg md:text-xl font-light">What concept shall we master today?</p>
            </div>
            
            <div className="flex gap-4">
               <div className="group glass-panel px-6 py-3 rounded-2xl flex items-center gap-4 transition-all hover:bg-slate-800/80 cursor-default border-slate-700/50">
                  <div className="p-2 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl text-white shadow-lg group-hover:scale-110 transition-transform duration-300">
                     <Zap className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                     <span className="block text-xs text-slate-400 font-bold uppercase tracking-wider">Total XP</span>
                     <span className="font-bold text-2xl text-white leading-none">{user.points}</span>
                  </div>
               </div>
            </div>
         </div>
      </div>

      {/* Main Search Area */}
      <div className="w-full max-w-4xl mx-auto relative z-10">
         <form onSubmit={handleSubmit} className="relative group">
            <div className="absolute inset-y-0 left-0 pl-8 flex items-center pointer-events-none">
                <Search className="text-slate-400 group-focus-within:text-indigo-400 transition-colors w-7 h-7" />
            </div>
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything (e.g., 'Quantum Physics', 'French Revolution')"
              className="w-full bg-slate-900/40 backdrop-blur-2xl border border-slate-700/50 text-white text-2xl py-8 pl-20 pr-40 rounded-[2rem] shadow-2xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500/50 outline-none transition-all placeholder:text-slate-500/50 hover:bg-slate-900/60"
            />
            <div className="absolute inset-y-0 right-4 flex items-center gap-2">
                 <button type="button" className="p-4 hover:bg-white/5 rounded-2xl text-slate-400 hover:text-white transition-all active:scale-95 group/btn" title="Voice Search">
                    <Mic size={24} className="group-hover/btn:text-indigo-400 transition-colors" />
                 </button>
                 <button 
                   type="submit" 
                   className="bg-indigo-600 hover:bg-indigo-500 text-white p-4 rounded-2xl font-medium transition-all shadow-lg shadow-indigo-600/30 active:scale-95 hover:scale-105"
                 >
                    <ChevronRight size={28} />
                 </button>
            </div>
         </form>
         
         <div className="mt-8 flex flex-col items-center">
             <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-4">Trending Now</p>
             <div className="flex flex-wrap justify-center gap-3">
             {['Newton\'s Laws', 'Periodic Table', 'Photosynthesis', 'Calculus', 'World War II', 'Genetics'].map(t => (
                 <button 
                   key={t}
                   onClick={() => onTopicSelect(t)} 
                   className="px-5 py-2 bg-slate-800/40 hover:bg-slate-700/60 border border-slate-700/50 rounded-full text-slate-300 transition-all text-sm font-medium hover:text-white hover:border-indigo-500/30 hover:-translate-y-0.5"
                 >
                    {t}
                 </button>
             ))}
             </div>
         </div>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
          <button 
             onClick={onVivaSelect}
             className="text-left glass-card p-8 rounded-[2rem] group relative overflow-hidden border-slate-700/30 hover:border-indigo-500/30 transition-all"
          >
             <div className="absolute -right-10 -top-10 w-40 h-40 bg-indigo-500/10 rounded-full blur-3xl group-hover:bg-indigo-500/20 transition-colors"></div>
             
             <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-400 mb-6 group-hover:scale-110 group-hover:bg-indigo-500/20 transition-all border border-indigo-500/10 shadow-lg shadow-indigo-500/5">
                 <Mic size={32} />
             </div>
             
             <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-indigo-300 transition-colors">Viva Practice</h3>
             <p className="text-slate-400 text-sm leading-relaxed mb-6">Master oral exams with our AI examiner. Get real-time confidence scores and feedback.</p>
             
             <div className="flex items-center text-xs font-bold text-indigo-400 uppercase tracking-wider group-hover:translate-x-1 transition-transform bg-indigo-500/10 w-fit px-3 py-1.5 rounded-full">
                Start Session <ChevronRight size={14} className="ml-1" />
             </div>
          </button>

          <button 
             className="text-left glass-card p-8 rounded-[2rem] group relative overflow-hidden border-slate-700/30 hover:border-purple-500/30 transition-all"
          >
             <div className="absolute -right-10 -top-10 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl group-hover:bg-purple-500/20 transition-colors"></div>

             <div className="w-16 h-16 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400 mb-6 group-hover:scale-110 group-hover:bg-purple-500/20 transition-all border border-purple-500/10 shadow-lg shadow-purple-500/5">
                 <Video size={32} />
             </div>
             
             <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">Video Lessons</h3>
             <p className="text-slate-400 text-sm leading-relaxed mb-6">Generated cinematic explanations for any topic. Watch, listen, and learn visually.</p>
             
             <div className="flex items-center text-xs font-bold text-purple-400 uppercase tracking-wider group-hover:translate-x-1 transition-transform bg-purple-500/10 w-fit px-3 py-1.5 rounded-full">
                Browse Library <ChevronRight size={14} className="ml-1" />
             </div>
          </button>

          <button 
             className="text-left glass-card p-8 rounded-[2rem] group relative overflow-hidden border-slate-700/30 hover:border-emerald-500/30 transition-all"
          >
             <div className="absolute -right-10 -top-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-colors"></div>

             <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 mb-6 group-hover:scale-110 group-hover:bg-emerald-500/20 transition-all border border-emerald-500/10 shadow-lg shadow-emerald-500/5">
                 <TrendingUp size={32} />
             </div>
             
             <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-emerald-300 transition-colors">My Progress</h3>
             <p className="text-slate-400 text-sm leading-relaxed mb-6">Track your learning streak, view earned badges, and analyze your weak areas.</p>
             
             <div className="flex items-center text-xs font-bold text-emerald-400 uppercase tracking-wider group-hover:translate-x-1 transition-transform bg-emerald-500/10 w-fit px-3 py-1.5 rounded-full">
                View Stats <ChevronRight size={14} className="ml-1" />
             </div>
          </button>
      </div>

    </div>
  );
};

export default Dashboard;