import { GoogleGenAI, Type, Modality } from "@google/genai";
import { StudyResponse, VivaFeedback } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Using Flash for fast reasoning
const REASONING_MODEL = 'gemini-3-flash-preview';
// Using specific image model
const IMAGE_MODEL = 'gemini-2.5-flash-image';
// Using TTS model
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';
// Using Veo for video
const VIDEO_MODEL = 'veo-3.1-fast-generate-preview';

// Helper to clean JSON output
const cleanJson = (text: string): string => {
  return text.replace(/```json|```/g, '').trim();
};

export const generateStudyContent = async (
  topic: string, 
  userStyle: string, 
  userGrade: string
): Promise<StudyResponse> => {
  
  const prompt = `
    You are an expert AI tutor creating a script for a short educational video lesson.
    Target Student: ${userGrade} level.
    Topic: "${topic}".
    Learning Style: ${userStyle}.
    
    Provide the response in a structured JSON format with:
    1. explanation: A conversational, engaging video script (approx 120-150 words). It should sound like a friendly teacher speaking directly to the student, using analogies and simple language. Do not use headers or bullet points in the script text.
    2. visualPrompt: A detailed prompt to generate an educational, anime-style, cinematic illustration that perfectly visualizes this concept.
    3. memoryTrick: A short, catchy mnemonic, rhyme, or "cheat code" to remember the key concept.
    4. flowchartSteps: 3-5 short, logical steps breaking down the concept linearly.
    5. quizQuestion: A conceptual multiple-choice question to check deep understanding.
    6. quizOptions: 4 clear options.
    7. quizAnswer: Index of correct answer (0-3).
  `;

  const response = await ai.models.generateContent({
    model: REASONING_MODEL,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          explanation: { type: Type.STRING },
          visualPrompt: { type: Type.STRING },
          memoryTrick: { type: Type.STRING },
          flowchartSteps: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          quizQuestion: { type: Type.STRING },
          quizOptions: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          quizAnswer: { type: Type.INTEGER, description: "Index of correct answer (0-3)" }
        },
        required: ["explanation", "visualPrompt", "memoryTrick", "flowchartSteps", "quizQuestion", "quizOptions", "quizAnswer"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  try {
    return JSON.parse(cleanJson(text)) as StudyResponse;
  } catch (e) {
    console.error("JSON Parse Error", text);
    throw new Error("Failed to parse AI response");
  }
};

export const generateVisual = async (prompt: string): Promise<string> => {
  const fullPrompt = `Anime style educational illustration, masterpiece, high quality, clear lines, vibrant colors, cinematic lighting: ${prompt}`;
  
  const response = await ai.models.generateContent({
    model: IMAGE_MODEL,
    contents: fullPrompt,
  });

  if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
              return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          }
      }
  }
  
  return ""; 
};

export const generateVideoLoop = async (prompt: string): Promise<string | null> => {
    try {
        // Veo check for paid key
        if (typeof window !== 'undefined' && (window as any).aistudio) {
            const hasKey = await (window as any).aistudio.hasSelectedApiKey();
            if (!hasKey) {
                console.log("Veo skipped: No paid key selected.");
                return null;
            }
        }
        
        // Re-init with potentially new key
        const aiVideo = new GoogleGenAI({ apiKey: process.env.API_KEY });

        let operation = await aiVideo.models.generateVideos({
            model: VIDEO_MODEL,
            prompt: `Cinematic, slow motion, educational loop, highly detailed, 4k, ${prompt}`,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });

        // Poll for completion
        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            operation = await aiVideo.operations.getVideosOperation({ operation });
        }

        const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (videoUri) {
            return `${videoUri}&key=${process.env.API_KEY}`;
        }
    } catch (e) {
        console.error("Video generation failed", e);
    }
    return null;
};

export const evaluateVivaAnswer = async (question: string, userAnswer: string): Promise<VivaFeedback> => {
  const prompt = `
    Question: ${question}
    Student Answer: ${userAnswer}
    
    Evaluate the student's answer as a strict but encouraging examiner.
    Give a confidence score (0-100), concise feedback (max 2 sentences), 2 actionable improvement tips, and the ideal corrected answer.
  `;

  const response = await ai.models.generateContent({
    model: REASONING_MODEL,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.INTEGER },
          feedback: { type: Type.STRING },
          tips: { type: Type.ARRAY, items: { type: Type.STRING } },
          correctedAnswer: { type: Type.STRING }
        },
        required: ["score", "feedback", "tips", "correctedAnswer"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  try {
    return JSON.parse(cleanJson(text)) as VivaFeedback;
  } catch (e) {
    console.error("JSON Parse Error", text);
    throw new Error("Failed to parse AI response");
  }
};

export const generateSpeech = async (text: string): Promise<ArrayBuffer> => {
  const response = await ai.models.generateContent({
    model: TTS_MODEL,
    contents: {
      parts: [{ text: text }]
    },
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' } 
        }
      }
    }
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("No audio data returned");
  }

  const binaryString = atob(base64Audio);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
};