export enum AppView {
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD',
  STUDY_SESSION = 'STUDY_SESSION',
  VIVA_MODE = 'VIVA_MODE'
}

export interface UserProfile {
  name: string;
  grade: string;
  examGoal: string; // e.g., NEET, JEE, General
  style: 'visual' | 'text' | 'audio';
  points: number;
  streak: number;
  badges: string[];
}

export interface StudyResponse {
  explanation: string;
  visualPrompt: string;
  memoryTrick: string;
  flowchartSteps: string[];
  quizQuestion: string;
  quizOptions: string[];
  quizAnswer: number; // Index
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isVisual?: boolean;
  visualUrl?: string;
}

export enum VivaState {
  IDLE = 'IDLE',
  LISTENING = 'LISTENING',
  PROCESSING = 'PROCESSING',
  FEEDBACK = 'FEEDBACK'
}

export interface VivaFeedback {
  score: number;
  feedback: string;
  tips: string[];
  correctedAnswer: string;
}
