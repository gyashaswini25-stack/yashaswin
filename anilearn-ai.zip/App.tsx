import React, { useState } from 'react';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import StudySession from './components/StudySession';
import VivaMode from './components/VivaMode';
import { UserProfile, AppView } from './types';
import { Menu, X, Home, User, Settings, LogOut, Sparkles } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.ONBOARDING);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentTopic, setCurrentTopic] = useState<string>('');
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const handleOnboardingComplete = (profile: UserProfile) => {
    setUser(profile);
    setView(AppView.DASHBOARD);
  };

  const handleTopicSelect = (topic: string) => {
    setCurrentTopic(topic);
    setView(AppView.STUDY_SESSION);
  };

  const handleVivaSelect = () => {
      setView(AppView.VIVA_MODE);
  };

  const updatePoints = (pts: number) => {
      if (user) {
          setUser({ ...user, points: user.points + pts });
      }
  };

  if (view === AppView.ONBOARDING) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="min-h-screen text-slate-100 flex overflow-hidden selection:bg-indigo-500/30 selection:text-indigo-200">
        {/* Sidebar Navigation */}
        <aside className={`fixed md:relative z-30 w-72 h-screen bg-slate-950/80 backdrop-blur-xl border-r border-slate-800/50 transition-transform duration-300 flex flex-col ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
            <div className="p-8 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                        <Sparkles size={18} />
                    </div>
                    <h1 className="text-2xl font-bold tracking-tight text-white">Ani<span className="text-indigo-500">Learn</span></h1>
                </div>
                <button onClick={() => setSidebarOpen(false)} className="md:hidden text-slate-400 hover:text-white transition">
                    <X size={24} />
                </button>
            </div>
            
            <nav className="px-6 space-y-2 mt-2 flex-1">
                <button 
                  onClick={() => setView(AppView.DASHBOARD)}
                  className={`w-full flex items-center gap-3 px-4 py-4 rounded-2xl transition-all duration-200 font-medium ${view === AppView.DASHBOARD ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-400 hover:bg-slate-900 hover:text-white'}`}
                >
                    <Home size={20} /> Dashboard
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl text-slate-400 hover:bg-slate-900 hover:text-white transition-all duration-200 font-medium">
                    <User size={20} /> Profile
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl text-slate-400 hover:bg-slate-900 hover:text-white transition-all duration-200 font-medium">
                    <Settings size={20} /> Settings
                </button>
            </nav>

            <div className="p-6">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-900/40 to-purple-900/40 border border-indigo-500/20 mb-4">
                    <h4 className="font-bold text-white mb-1">Premium Plan</h4>
                    <p className="text-xs text-indigo-200 mb-3">Unlock unlimited visuals</p>
                    <button className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs font-bold text-white transition-colors">Upgrade</button>
                </div>

                <button 
                  onClick={() => setView(AppView.ONBOARDING)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-colors text-sm font-medium"
                >
                    <LogOut size={18} /> Sign Out
                </button>
            </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
            {/* Mobile Header */}
            <header className="md:hidden h-16 flex items-center px-6 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-20">
                <button onClick={() => setSidebarOpen(true)} className="text-slate-400 mr-4">
                    <Menu size={24} />
                </button>
                <span className="font-bold text-lg">AniLearn AI</span>
            </header>

            <div className="flex-1 overflow-y-auto scroll-smooth">
                {view === AppView.DASHBOARD && user && (
                    <Dashboard 
                        user={user} 
                        onTopicSelect={handleTopicSelect} 
                        onVivaSelect={handleVivaSelect}
                    />
                )}
                
                {view === AppView.STUDY_SESSION && user && (
                    <StudySession 
                        topic={currentTopic} 
                        user={user} 
                        onBack={() => setView(AppView.DASHBOARD)} 
                        onPointsUpdate={updatePoints}
                    />
                )}

                {view === AppView.VIVA_MODE && (
                    <VivaMode 
                        onBack={() => setView(AppView.DASHBOARD)} 
                        topic={currentTopic ? currentTopic : undefined}
                    />
                )}
            </div>
        </main>
    </div>
  );
};

export default App;